import React, {useContext,   useEffect, useState} from 'react';
import './Tray.css';
import {
    TYPE_MUTE_CAMERA,
    TYPE_MUTE_MIC,
    TYPE_SCREEN,
    // TYPE_LEAVE,
} from '../TrayButton/TrayButton';

import CallObjectContext from '../../CallObjectContext';
import {logDailyEvent} from '../../logUtils';
import DailyIframe from '@daily-co/daily-js';
import cameraon from "../../icon/cameraon.png";
import cameraoff from "../../icon/cameraoff.png";
import micon from "../../icon/micon.png";
import micoff from "../../icon/micoff.png";
import screenon from "../../icon/screenshare.png";
import screenoff from "../../icon/screenshareoff.png";
import left from "../../icon/left.png";
import right from "../../icon/right.png";
import settings from "../../icon/settings.png";
import screensharedisable from "../../icon/screensharedisable.png";

// import {isScreenShare} from "../Call/callState";


/**
 * Gets [isCameraMuted, isMicMuted, isSharingScreen].
 * This function is declared outside Tray() so it's not recreated every render
 * (which would require us to declare it as a useEffect dependency).
 */
function getStreamStates(callObject) {
    let isCameraMuted,
        isMicMuted,
        isSharingScreen,
        isSharingScreenExist = false;
    if (
        callObject &&
        callObject.participants() &&
        callObject.participants().local
    ) {
        for (const [key, value] of Object.entries(callObject.participants())) {
            if (value.screen)
            {
                isSharingScreenExist = true;
                break;
            }
        }

        const localParticipant = callObject.participants().local;
        isCameraMuted = !localParticipant.video;
        isMicMuted = !localParticipant.audio;
        isSharingScreen = localParticipant.screen;

    }

    return [isCameraMuted, isMicMuted, isSharingScreen, isSharingScreenExist];
}

/**
 * Props:
 * - onClickLeaveCall: () => ()
 * - disabled: boolean
 */
export default function Tray(props) {
    const callObject = useContext(CallObjectContext);
    const [isCameraMuted, setCameraMuted] = useState(false);
    const [isMicMuted, setMicMuted] = useState(false);
    const [isSharingScreen, setSharingScreen] = useState(false);
    const [isOpenSettings, setOpenSettings] = useState(false);
    const [isSharingScreenExist, setSharingScreenExist] = useState(false);


    function toggleCamera() {
        let videoOff;
        callObject.setLocalVideo(isCameraMuted);
        if(isCameraMuted){
            setVideoOff();
            videoOff = 0;
        }else{
            setVideoOn();
            videoOff = 1;
        }
        fetch(props.videoUrlOff + '/' + videoOff).then(()=>{})
    }

    function toggleMic() {
        let audioOff;
        callObject.setLocalAudio(isMicMuted);
        if(isMicMuted){
            audioOff = 0;
        }else{
            audioOff = 1;
        }
        fetch( props.audioUrlOff + '/' + audioOff).then(()=>{})
    }

    function toggleSharingScreen() {

        if (isSharingScreen)
        {
            callObject.stopScreenShare();
        }
        else
        {
            callObject.startScreenShare();
        }

    }

    function goLeft() {
        document.querySelector('.small-tiles').scrollLeft -= 200;
    }

    function goRight() {
        document.querySelector('.small-tiles').scrollLeft += 200;
    }

    function toggleVideoTracks() {
        let toggleBtn = document.querySelector('.small-tiles-btn');
        if (toggleBtn && toggleBtn.classList.contains('small-tiles-btn-show')) {
            toggleBtn.classList.remove('small-tiles-btn-show');
            toggleBtn.classList.add('small-tiles-btn-hide');
            document.querySelector('.small-mode').classList.add('show-mobile-small-tiles');
        } else {
            toggleBtn.classList.remove('small-tiles-btn-hide');
            toggleBtn.classList.add('small-tiles-btn-show');
            document.querySelector('.small-mode').classList.remove('show-mobile-small-tiles');
        }
    }

    function openSettingsBlock() {
        setOpenSettings(!isOpenSettings)
        if(!isOpenSettings){
            document.querySelector('.settings-block').classList.add('open-settings-block');
        }else{
            document.querySelector('.settings-block').classList.remove('open-settings-block');
        }




    }



    /**
     * Start listening for participant changes when callObject is set (i.e. when the component mounts).
     * This event will capture any changes to your audio/video mute state.
     */
    useEffect(() => {
        if (!callObject) return;

        function handleNewParticipantsState(event) {
            event && logDailyEvent(event);
            const [isCameraMuted, isMicMuted, isSharingScreen,isSharingScreenExist] = getStreamStates(
                callObject
            );
            setCameraMuted(isCameraMuted);
            setMicMuted(isMicMuted);
            setSharingScreen(isSharingScreen);
            setSharingScreenExist(isSharingScreenExist)
        }

        // Use initial state
        handleNewParticipantsState();

        // Listen for changes in state
        callObject.on('participant-updated', handleNewParticipantsState);

        // Stop listening for changes in state
        return function cleanup() {
            callObject.off('participant-updated', handleNewParticipantsState);
        };
    }, [callObject]);

    window.mobileAndTabletCheck = function () {
        let check = false;
        (function (a) {
            if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw(n|u)|c55\/|capi|ccwa|cdm|cell|chtm|cldc|cmd|co(mp|nd)|craw|da(it|ll|ng)|dbte|dcs|devi|dica|dmob|do(c|p)o|ds(12|d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(|_)|g1 u|g560|gene|gf5|gmo|go(\.w|od)|gr(ad|un)|haie|hcit|hd(m|p|t)|hei|hi(pt|ta)|hp( i|ip)|hsc|ht(c(| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i(20|go|ma)|i230|iac( ||\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|[a-w])|libw|lynx|m1w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|mcr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|([1-8]|c))|phil|pire|pl(ay|uc)|pn2|po(ck|rt|se)|prox|psio|ptg|qaa|qc(07|12|21|32|60|[2-7]|i)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h|oo|p)|sdk\/|se(c(|0|1)|47|mc|nd|ri)|sgh|shar|sie(|m)|sk0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h|v|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl|tdg|tel(i|m)|tim|tmo|to(pl|sh)|ts(70|m|m3|m5)|tx9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas|your|zeto|zte/i.test(a.substr(0, 4))) check = true;
        })(navigator.userAgent || navigator.vendor || window.opera);

        return check;
    };

    let deviceIsNotPC = window.mobileAndTabletCheck();

    function setVideoOff(){

        navigator.mediaDevices.enumerateDevices()
            .then(devices => {
                var cams = devices.filter(device => device.kind === "videoinput");
                if (cams.length) {
                    return navigator.mediaDevices.getUserMedia({
                        video: {deviceId: {exact: cams[0].deviceId}},
                    })
                        .then(stream => stream.getTracks().forEach(track => {
                            track.enabled = false;
                        }));
                }
            });
    }


    function setVideoOn(){

        navigator.mediaDevices.enumerateDevices()
            .then(devices => {
                var cams = devices.filter(device => device.kind === "videoinput");
                if (cams.length) {
                    return navigator.mediaDevices.getUserMedia({
                        video: {deviceId: {exact: cams[0].deviceId}},
                    })
                        .then(
                            stream => stream.getTracks().forEach(track => {
                                track.enabled = true;
                                //localStorage.getItem("isCamMuted")===true
                            }));
                }
            });

    }






    return (
        <div className={`tray ${window.innerWidth > 767 ? 'tray-show-hide' : ''}`}>

            <button
                type={TYPE_MUTE_CAMERA}
                disabled={props.disabled}
                onClick={toggleCamera}
                className="tray-btn"
                title={!isCameraMuted ? 'Off' : 'On'}
            ><img src={!isCameraMuted ? cameraon : cameraoff} alt="cam-on"/></button>

            <button
                type={TYPE_MUTE_MIC}
                disabled={props.disabled}
                onClick={toggleMic}
                title={!isMicMuted ? 'Mute' : 'Unmute'}
                className={`tray-btn ${!DailyIframe.supportedBrowser().supportsScreenShare && deviceIsNotPC ? 'dont-have-screen-share-access' : ''}`}
            ><img src={!isMicMuted ? micon : micoff} alt="mic-on"/></button>

            { isSharingScreenExist ?
                (isSharingScreen ?
                        (
                            <button
                                type={TYPE_SCREEN}
                                disabled={props.disabled}
                                onClick={toggleSharingScreen}
                                className={`tray-btn ${deviceIsNotPC ? 'tray-buttons-mobile' : null}`}
                                title={!isSharingScreen ? 'Share' : 'Stop'}
                            ><img src={!isSharingScreen ? screenon : screenoff} alt="screen-on"/></button>
                        )
                        :
                        (
                            <button
                                type={TYPE_SCREEN}
                                disabled={true}
                                onClick={toggleSharingScreen}
                                className={`tray-btn ${deviceIsNotPC ? 'tray-buttons-mobile' : null}`}
                                title={"Disabled"}
                            ><img src={screensharedisable} alt="screen-disable"/></button>

                        )
                )
                :

                ( DailyIframe.supportedBrowser().supportsScreenShare &&
                    <button
                        type={TYPE_SCREEN}
                        disabled={props.disabled}
                        onClick={toggleSharingScreen}
                        className={`tray-btn ${deviceIsNotPC ? 'tray-buttons-mobile' : null}`}
                        title={!isSharingScreen ? 'Share' : 'Stop'}
                    ><img src={!isSharingScreen ? screenon : screenoff} alt="screen-on"/></button>)
            }

            <span className="leftRightBtns" >
                <span onClick={goLeft} className="leftBtn"><img src={left} alt="Left"/></span>
                <span onClick={goRight} className="rightBtn"><img src={right} alt="Right"/></span>
            </span>

            <span className="small-tiles-btn small-tiles-btn-show"><img onClick={toggleVideoTracks} src={left}
                                                                        alt="open"/></span>
            {!deviceIsNotPC ?
                <button className="tray-btn" title="Settings" onClick={openSettingsBlock}>
                    <img src={settings} alt="settings"/>
                </button> : null
            }
        </div>
    );
}
