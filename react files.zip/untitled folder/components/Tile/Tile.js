import React, {useEffect, useRef} from 'react';
import './Tile.css';

/**
 * Props
 * - videoTrack: MediaStreamTrack?
 * - audioTrack: MediaStreamTrack?
 * - isLocalPerson: boolean
 * - isLarge: boolean
 * - isLoading: boolean
 * - onClick: Function
 */
export default function Tile(props) {
    const videoEl = useRef(null);
    const audioEl = useRef(null);

    /**
     * When video track changes, update video srcObject
     */
    useEffect(() => {
        videoEl.current &&
        (videoEl.current.srcObject = new MediaStream([props.videoTrack]));
    }, [props.videoTrack]);

    /**
     * When audio track changes, update audio srcObject
     */
    useEffect(() => {
        audioEl.current &&
        (audioEl.current.srcObject = new MediaStream([props.audioTrack]));
    }, [props.audioTrack]);

    function getLoadingComponent() {
        return props.isLoading && <p className="loading"></p>;
    }

    function getVideoComponent() {
        return (
            props.videoTrack && <video autoPlay muted playsInline ref={videoEl} onClick={hey}/> // Custom Code
        );
    }

    // Custom Cod
    function hey(e) {
        // e.target.className = 'video-click';
        // e.target.parentElement.className = 'video-click';
    }

    // Custom Cod
    function getAudioComponent() {
        return (
            !props.isLocalPerson &&
            props.audioTrack && <audio autoPlay playsInline ref={audioEl}/>
        );
    }

    function getClassNames() {
        let classNames = `tile ${!props.isLoading ? props.cam : ''} ${!props.isLoading ? props.mic : ''}
        ${!props.isLoading ? 'tile-username' : ''} ${props.activeSpeaker} ${props.screen ? 'isScreen' : ''}`;
        classNames += props.isLarge ? ' large' : ' small';
        props.isLocalPerson && (classNames += ' local');
        !props.isLocalPerson && (classNames += ' remote');
        return classNames;
    }

    return (
        <div className={getClassNames()} onClick={props.onClick} username={!props.isLoading ? props.username : ''}>
            <div className="background" style={props.userAvatars[props.userid]?{backgroundImage:`url(${props.userAvatars[props.userid]})`}:{backgroundImage:''}}/>
            {getLoadingComponent()}
            {getVideoComponent()}
            {getAudioComponent()}
        </div>
    );
}
