import React, {useEffect, useContext, useReducer, useCallback, useState} from 'react';
import './Call.css';
import Tile from '../Tile/Tile';
import CallObjectContext from '../../CallObjectContext';
import {
    initialCallState,
    CLICK_ALLOW_TIMEOUT,
    PARTICIPANTS_CHANGE,
    CAM_OR_MIC_ERROR,
    FATAL_ERROR,
    callReducer,
    isLocal,
    isScreenShare,
    containsScreenShare
} from './callState';
import {logDailyEvent} from '../../logUtils';

export default function Call(props) {
    const callObject = useContext(CallObjectContext);
    const [callState, dispatch] = useReducer(callReducer, initialCallState);
    const [activeId, setActiveId] = useState('');
    const [option,setOption] = useState(false);

    /**
     * Start listening for participant changes, when the callObject is set.
     */
    useEffect(() => {
        if (!callObject) return;
        const events = [
            'participant-joined',
            'participant-updated',
            'participant-left',
        ];

        function handleNewParticipantsState(event) {
            event && logDailyEvent(event);
            dispatch({
                type: PARTICIPANTS_CHANGE,
                participants: callObject.participants(),
            });
        }

        //Use initial state
        handleNewParticipantsState();
        // Listen for changes in state
        for (const event of events) {
            callObject.on(event, handleNewParticipantsState);
        }

        // Stop listening for changes in state
        return function cleanup() {
            for (const event of events) {
                callObject.off(event, handleNewParticipantsState);
            }
        };
    }, [callObject]);

    /**
     * Start listening for call errors, when the callObject is set.
     */
    useEffect(() => {
        if (!callObject) return;

        function handleCameraErrorEvent(event) {
            logDailyEvent(event);
            dispatch({
                type: CAM_OR_MIC_ERROR,
                message:
                    (event && event.errorMsg && event.errorMsg.errorMsg) || 'Unknown',
            });
        }

        // We're making an assumption here: there is no camera error when callObject
        // is first assigned.

        callObject.on('camera-error', handleCameraErrorEvent);

        return function cleanup() {
            callObject.off('camera-error', handleCameraErrorEvent);
        };
    }, [callObject]);

    /**
     * Start listening for fatal errors, when the callObject is set.
     */
    useEffect(() => {
        if (!callObject) return;

        function handleErrorEvent(e) {
            logDailyEvent(e);
            dispatch({
                type: FATAL_ERROR,
                message: (e && e.errorMsg) || 'Unknown',
            });
        }

        // We're making an assumption here: there is no error when callObject is
        // first assigned.

        callObject.on('error', handleErrorEvent);

        return function cleanup() {
            callObject.off('error', handleErrorEvent);
        };
    }, [callObject]);

    /**
     * Start a timer to show the "click allow" message, when the component mounts.
     */
    useEffect(() => {
        const t = setTimeout(() => {
            dispatch({type: CLICK_ALLOW_TIMEOUT});
        }, 2500);

        return function cleanup() {
            clearTimeout(t);
        };
    }, []);

    /**
     * Send an app message to the remote participant whose tile was clicked on.
     */
    const sendHello = useCallback(
        (participantId) => {
            callObject &&
            callObject.sendAppMessage({hello: 'world'}, participantId);
        },
        [callObject]
    );
// activeSpeaker={id === activeId && option===false? 'active-speaker' : id === activeId && option===true? 'active-speaker-grid' : ''}
    function getTiles() {
        let largeTiles = [];
        Object.entries(callState.callItems).forEach(([id, callItem]) => {
            const isLarge =
                isScreenShare(id) ||
                (!isLocal(id) && !containsScreenShare(callState.callItems));
            const tile = (
                <Tile
                    key={id}
                    videoTrack={callItem.videoTrack}
                    audioTrack={callItem.audioTrack}
                    isLocalPerson={isLocal(id)}
                    isLarge={isLarge}
                    activeSpeaker={id === activeId? 'active-speaker' : ''}
                    screen={callItem.screen}
                    isLoading={callItem.isLoading}
                    cam={callItem.videoTrack ? 'cam-on' : 'cam-muted'}
                    mic={callItem.audioTrack ? 'mic-on' : 'mic-muted'}
                    username={callItem.user_name ? callItem.user_name : ''}
                    userid={callItem.user_id}
                    userAvatars={props.userAvatars}
                    onClick={
                        isLocal(id)
                            ? null
                            : () => {
                                sendHello(id);
                            }
                    }
                />
            );
              //if(largeTiles.length < 2){
                largeTiles.push(tile);
              //}
        });
        return largeTiles;
    }
    function getLocalTile() {
        let callItem = callState.callItems['local'];
        let id = 'local';
        const isLarge =
            isScreenShare(id) ||
            (!isLocal(id) && !containsScreenShare(callState.callItems));
        const local = (
            <Tile
                key={id}
                videoTrack={callItem.videoTrack}
                audioTrack={callItem.audioTrack}
                isLocalPerson={isLocal(id)}
                isLarge={isLarge}
                activeSpeaker=""
                screen={callItem.screen}
                isLoading={callItem.isLoading}
                cam={callItem.videoTrack ? 'cam-on' : 'cam-muted'}
                mic={callItem.audioTrack ? 'mic-on' : 'mic-muted'}
                username={callItem.user_name ? callItem.user_name : ''}
                userid={callItem.user_id}
                userAvatars={props.userAvatars}
                onClick={
                    isLocal(id)
                        ? null
                        : () => {
                            sendHello(id);
                        }
                }
            />
        );

        let localArr = [];
        localArr.push(local);
        return localArr;
    }
    function getActiveSpeakerTile() {
        var activeArr = [];
        callObject.on('active-speaker-change', data => {
            if(data.activeSpeaker.peerId){
                setActiveId(data.activeSpeaker.peerId);
            }
        });

        if (activeId) {
            //there is some speaker
            window.speakerDetected = false;

            Object.entries(callState.callItems).forEach(([id, callItem]) => {
                if (id === activeId) {
                    window.speakerDetected = true;
                    const isLarge =
                        isScreenShare(id) ||
                        (!isLocal(id) && !containsScreenShare(callState.callItems));
                    const active = (
                        <Tile
                            key={id}
                            videoTrack={callItem.videoTrack}
                            audioTrack={callItem.audioTrack}
                            isLocalPerson={isLocal(id)}
                            isLarge={isLarge}
                            activeSpeaker=' '
                            screen={callItem.screen}
                            isLoading={callItem.isLoading}
                            cam={callItem.videoTrack ? 'cam-on' : 'cam-muted'}
                            mic={callItem.audioTrack ? 'mic-on' : 'mic-muted'}
                            username={callItem.user_name ? callItem.user_name : ''}
                            userid={callItem.user_id}
                            userAvatars={props.userAvatars}
                            onClick={
                                isLocal(id)
                                    ? null
                                    : () => {
                                        sendHello(id);
                                    }
                            }
                        />
                    );
                    activeArr = [];
                    activeArr.push(active);
                }
            });

            if(!window.speakerDetected){
                //not detected means need to show local user
                activeArr = [];
                activeArr = getLocalTile();
            }
        }else{
            //there is no one speaking
            //showing local user
            activeArr = [];
            activeArr = getLocalTile();
        }
        return activeArr;

    }

    const largeTiles = getTiles();
    var tileLength = largeTiles.length;
    var check = false;
    for (var i = 0; i < largeTiles.length; i++) {
        if (largeTiles[i].props.screen) {
            check = true;
            tileLength--;
            break;
        }
        if (i === largeTiles.length - 1 && !check) {
            tileLength = largeTiles.length;
        }
    }

    const activeResult = getActiveSpeakerTile();
    const localTile = getLocalTile();
    return (
        <div className={`call${check ? ' have-shared-screen' : ''}`}>
            <div
                className={`large-tiles tiles-${tileLength} ${tileLength > 4 ? 'max' : ''} ${tileLength > 4 && !activeResult ? 'no-active-speaker' : ''} `}>
            {
                tileLength < 5
                ? largeTiles
                : activeResult ? activeResult
                : localTile
            }
                </div>
                <div
                className={`small-tiles small-tiles-${tileLength} ${check ? 'with-screen-child' : ''} ${tileLength > 4 ? 'small-mode' : ''}`}>
            {
                tileLength > 4
                ? largeTiles
                : null
            }
                </div>
    </div>


    );

}
